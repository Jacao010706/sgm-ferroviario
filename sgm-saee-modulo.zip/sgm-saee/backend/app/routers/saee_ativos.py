from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import or_, func, case
from typing import Optional, List
from datetime import date, timedelta
from pydantic import BaseModel

from app.database import get_db
from app.models.saee_ativo import SaeeAtivo

router = APIRouter(prefix="/saee-ativos", tags=["saee-ativos"])


# ── Schemas ──────────────────────────────────────────────────────────────────

class SaeeAtivoOut(BaseModel):
    id: int
    seq_planilha: Optional[int]
    num_ativo: Optional[str]
    local: Optional[str]
    sublocal: Optional[str]
    sistema: Optional[str]
    nome_ativo: Optional[str]
    tag: Optional[str]
    esp_tecnica: Optional[str]
    tag_diagrama: Optional[str]
    diagrama: Optional[str]
    item_contrato: Optional[str]
    periodicidade: Optional[str]
    area: Optional[str]
    data_ult_manu: Optional[date]
    proxima_manu: Optional[date]
    ativo: bool
    status: Optional[str]  # campo calculado: VENCIDO / PROXIMO / OK / SEM_DATA

    class Config:
        from_attributes = True


class ManutencaoRegistro(BaseModel):
    data_realizacao: date
    observacao: Optional[str] = None


class SaeeAtivoUpdate(BaseModel):
    local: Optional[str] = None
    sublocal: Optional[str] = None
    sistema: Optional[str] = None
    nome_ativo: Optional[str] = None
    tag: Optional[str] = None
    periodicidade: Optional[str] = None
    area: Optional[str] = None
    ativo: Optional[bool] = None


# ── Helpers ───────────────────────────────────────────────────────────────────

PERIODICIDADE_DIAS = {
    "MENSAL": 30,
    "BIMESTRAL": 61,
    "TRIMESTRAL": 91,
    "SEMESTRAL": 182,
    "ANUAL": 365,
    "BIENAL": 730,
}


def calcular_status(proxima_manu: Optional[date]) -> str:
    if proxima_manu is None:
        return "SEM_DATA"
    hoje = date.today()
    if proxima_manu < hoje:
        return "VENCIDO"
    if proxima_manu <= hoje + timedelta(days=30):
        return "PROXIMO"
    return "OK"


def enrich(ativo: SaeeAtivo) -> dict:
    d = {c.name: getattr(ativo, c.name) for c in ativo.__table__.columns}
    d["status"] = calcular_status(ativo.proxima_manu)
    return d


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("", response_model=dict)
def listar_ativos(
    sistema:       Optional[str] = Query(None),
    sublocal:      Optional[str] = Query(None),
    periodicidade: Optional[str] = Query(None),
    status:        Optional[str] = Query(None, description="VENCIDO | PROXIMO | OK | SEM_DATA"),
    busca:         Optional[str] = Query(None, description="Busca por nome, tag ou num_ativo"),
    ativo:         Optional[bool] = Query(True),
    page:          int = Query(1, ge=1),
    page_size:     int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db),
):
    """Lista ativos SAEE com filtros e paginação."""
    q = db.query(SaeeAtivo)

    if ativo is not None:
        q = q.filter(SaeeAtivo.ativo == ativo)
    if sistema:
        q = q.filter(SaeeAtivo.sistema == sistema)
    if sublocal:
        q = q.filter(SaeeAtivo.sublocal == sublocal)
    if periodicidade:
        q = q.filter(SaeeAtivo.periodicidade == periodicidade)
    if busca:
        like = f"%{busca}%"
        q = q.filter(or_(
            SaeeAtivo.nome_ativo.ilike(like),
            SaeeAtivo.tag.ilike(like),
            SaeeAtivo.num_ativo.ilike(like),
        ))

    # Filtro por status (calculado no Python, então precisamos filtrar na query)
    hoje = date.today()
    if status == "VENCIDO":
        q = q.filter(SaeeAtivo.proxima_manu < hoje)
    elif status == "PROXIMO":
        q = q.filter(
            SaeeAtivo.proxima_manu >= hoje,
            SaeeAtivo.proxima_manu <= hoje + timedelta(days=30),
        )
    elif status == "OK":
        q = q.filter(SaeeAtivo.proxima_manu > hoje + timedelta(days=30))
    elif status == "SEM_DATA":
        q = q.filter(SaeeAtivo.proxima_manu == None)

    # Ordenar: vencidos primeiro, depois por proxima_manu
    q = q.order_by(
        SaeeAtivo.proxima_manu.asc().nullslast()
    )

    total = q.count()
    items = q.offset((page - 1) * page_size).limit(page_size).all()

    return {
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size,
        "items": [enrich(a) for a in items],
    }


@router.get("/resumo", response_model=dict)
def resumo_ativos(db: Session = Depends(get_db)):
    """Retorna contadores por status para o dashboard."""
    hoje = date.today()
    em_30 = hoje + timedelta(days=30)

    total     = db.query(func.count(SaeeAtivo.id)).filter(SaeeAtivo.ativo == True).scalar()
    vencidos  = db.query(func.count(SaeeAtivo.id)).filter(
        SaeeAtivo.ativo == True, SaeeAtivo.proxima_manu < hoje
    ).scalar()
    proximos  = db.query(func.count(SaeeAtivo.id)).filter(
        SaeeAtivo.ativo == True,
        SaeeAtivo.proxima_manu >= hoje,
        SaeeAtivo.proxima_manu <= em_30,
    ).scalar()
    ok        = db.query(func.count(SaeeAtivo.id)).filter(
        SaeeAtivo.ativo == True, SaeeAtivo.proxima_manu > em_30
    ).scalar()
    sem_data  = db.query(func.count(SaeeAtivo.id)).filter(
        SaeeAtivo.ativo == True, SaeeAtivo.proxima_manu == None
    ).scalar()

    # Por sistema
    por_sistema = db.query(
        SaeeAtivo.sistema,
        func.count(SaeeAtivo.id).label("total"),
        func.count(case((SaeeAtivo.proxima_manu < hoje, 1))).label("vencidos"),
    ).filter(SaeeAtivo.ativo == True).group_by(SaeeAtivo.sistema).all()

    # Por periodicidade
    por_periodicidade = db.query(
        SaeeAtivo.periodicidade,
        func.count(SaeeAtivo.id).label("total"),
    ).filter(SaeeAtivo.ativo == True).group_by(SaeeAtivo.periodicidade).order_by(SaeeAtivo.periodicidade).all()

    return {
        "total": total,
        "vencidos": vencidos,
        "proximos_30d": proximos,
        "ok": ok,
        "sem_data": sem_data,
        "eficiencia_pct": round((ok / total * 100) if total else 0, 1),
        "por_sistema": [
            {"sistema": r.sistema or "Não informado", "total": r.total, "vencidos": r.vencidos}
            for r in por_sistema
        ],
        "por_periodicidade": [
            {"periodicidade": r.periodicidade or "Não informado", "total": r.total}
            for r in por_periodicidade
        ],
    }


@router.get("/filtros", response_model=dict)
def opcoes_filtros(db: Session = Depends(get_db)):
    """Retorna listas únicas de sistemas, sublocais e periodicidades para popular os filtros."""
    sistemas = [
        r[0] for r in db.query(SaeeAtivo.sistema).distinct().filter(SaeeAtivo.sistema != None).order_by(SaeeAtivo.sistema).all()
    ]
    sublocais = [
        r[0] for r in db.query(SaeeAtivo.sublocal).distinct().filter(SaeeAtivo.sublocal != None).order_by(SaeeAtivo.sublocal).all()
    ]
    periodicidades = [
        r[0] for r in db.query(SaeeAtivo.periodicidade).distinct().filter(SaeeAtivo.periodicidade != None).order_by(SaeeAtivo.periodicidade).all()
    ]
    return {
        "sistemas": sistemas,
        "sublocais": sublocais,
        "periodicidades": periodicidades,
    }


@router.get("/{ativo_id}", response_model=dict)
def detalhe_ativo(ativo_id: int, db: Session = Depends(get_db)):
    ativo = db.query(SaeeAtivo).filter(SaeeAtivo.id == ativo_id).first()
    if not ativo:
        raise HTTPException(status_code=404, detail="Ativo não encontrado")
    return enrich(ativo)


@router.post("/{ativo_id}/manutencao", response_model=dict)
def registrar_manutencao(
    ativo_id: int,
    body: ManutencaoRegistro,
    db: Session = Depends(get_db),
):
    """Registra execução de manutenção e recalcula próxima data."""
    ativo = db.query(SaeeAtivo).filter(SaeeAtivo.id == ativo_id).first()
    if not ativo:
        raise HTTPException(status_code=404, detail="Ativo não encontrado")

    periodo = (ativo.periodicidade or "").upper()
    dias = PERIODICIDADE_DIAS.get(periodo)
    if not dias:
        raise HTTPException(
            status_code=400,
            detail=f"Periodicidade '{ativo.periodicidade}' não reconhecida para cálculo de próxima data"
        )

    ativo.data_ult_manu = body.data_realizacao
    ativo.proxima_manu  = body.data_realizacao + timedelta(days=dias)
    db.commit()
    db.refresh(ativo)

    return {
        "mensagem": "Manutenção registrada com sucesso",
        "ativo_id": ativo_id,
        "data_realizada": str(body.data_realizacao),
        "proxima_manu": str(ativo.proxima_manu),
        "status": calcular_status(ativo.proxima_manu),
    }


@router.patch("/{ativo_id}", response_model=dict)
def atualizar_ativo(
    ativo_id: int,
    body: SaeeAtivoUpdate,
    db: Session = Depends(get_db),
):
    ativo = db.query(SaeeAtivo).filter(SaeeAtivo.id == ativo_id).first()
    if not ativo:
        raise HTTPException(status_code=404, detail="Ativo não encontrado")

    for field, value in body.dict(exclude_none=True).items():
        setattr(ativo, field, value)

    db.commit()
    db.refresh(ativo)
    return enrich(ativo)
