# Como aplicar os arquivos SAEE no SGM Ferroviário

## PASSO 1 — Banco de dados (Railway)

1. Abra o Railway dashboard
2. Vá em **PostgreSQL → Query**
3. Abra o arquivo `saee_ativos_import.sql`
4. Cole e execute **bloco por bloco** — cada bloco começa com `INSERT INTO saee_ativos` e termina com `;`
   - Primeiro execute o `CREATE TABLE` (Passo 1 do SQL)
   - Depois os 26 blocos de INSERT (Passo 2)
   - Por fim as queries de verificação (Passo 3)

---

## PASSO 2 — Backend (FastAPI)

### 2.1 — Copiar o modelo
```
backend/app/models/saee_ativo.py   ← copiar de sgm-saee/backend/app/models/saee_ativo.py
```

### 2.2 — Copiar o router
```
backend/app/routers/saee_ativos.py ← copiar de sgm-saee/backend/app/routers/saee_ativos.py
```

### 2.3 — Registrar o router no main.py
Abra `backend/app/main.py` e adicione:

```python
from app.routers import saee_ativos          # nova linha
app.include_router(saee_ativos.router)       # nova linha — junto com os outros routers
```

### 2.4 — Deploy no Railway
```bash
git add backend/app/models/saee_ativo.py
git add backend/app/routers/saee_ativos.py
git add backend/app/main.py
git commit -m "feat: módulo SAEE — ativos, filtros, resumo, baixa de manutenção"
git push
```

---

## PASSO 3 — Frontend (Next.js)

### 3.1 — Copiar a página
```
frontend/pages/saee.js ← copiar de sgm-saee/frontend/pages/saee.js
```

### 3.2 — Adicionar na sidebar
No componente de sidebar do SGM, adicione o link:

```jsx
<Link href="/saee">
  <a className={`...`}>⚡ Ativos SAEE</a>
</Link>
```

### 3.3 — Deploy
```bash
git add frontend/pages/saee.js
git commit -m "feat: página de ativos SAEE com filtros e baixa de manutenção"
git push
```

---

## O que estará funcionando

### Página `/saee`
- **5 cards de resumo**: Total, Vencidos, Próximos 30 dias, Em dia, % Eficiência
- **Barra de progresso por sistema**: mostra % de ativos em dia por categoria
- **Tabela com 2.590 ativos** paginada (50 por página)
- **Filtros**: busca por texto, sistema, sublocal, periodicidade, status
- **Cores automáticas**: linhas vermelhas = vencido, amarelas = próximos 30 dias
- **Modal "Dar baixa"**: seleciona data realizada → recalcula próxima manutenção automaticamente

### API
| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/saee-ativos` | Lista com filtros e paginação |
| GET | `/saee-ativos/resumo` | Contadores para dashboard |
| GET | `/saee-ativos/filtros` | Opções para os selects |
| GET | `/saee-ativos/{id}` | Detalhe de um ativo |
| POST | `/saee-ativos/{id}/manutencao` | Dar baixa e recalcular próxima data |
| PATCH | `/saee-ativos/{id}` | Editar campos do ativo |

---

## Verificar se funcionou

Após o deploy, acesse:
```
https://laudable-peace-production-09cd.up.railway.app/saee-ativos/resumo
```
Deve retornar JSON com os totais de ativos por status.
